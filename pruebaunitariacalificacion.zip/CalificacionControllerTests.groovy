package grailsapplication3



import org.junit.*
import grails.test.mixin.*
import java.*
import GrailsApplication3.*
import grails.test.*

//@TestFor(CalificacionController)
//@Mock(Calificacion)
//@Mock(Productos)
//@Mock(Usuario)
class CalificacionControllerTests extends GrailsUnitTestCase {
    
 
def calificacionService = new CalificacionService()

    
    void testSave() {
        Calificacion cali = new Calificacion()
        cali.setComentario("Holis")
        cali.setFechaCalificacion(calificacionService.convertirFecha("12/03/2013"))
        cali.setValorCalificacion(5) 
       def testInstances =[cali]
       mockDomain(Calificacion, testInstances)
//        def Usuario1 = new Usuario()
//        Usuario1.id =393
//        cali.usuario = Usuario1
//        def Producto1 = new Productos()
//        Producto1.id= 116
//        cali.producto = Producto1
//        //cali.save(flush: true)
//        Calificacion prueba = new Calificacion()
//        prueba.id= 404

        
        assertTrue cali.comentario.equals("Holis")
//        
//        assert model.calificacionInstance != null
//        assert view == '/calificacion/create'
//        
//        response.reset()
//        println("please print "+prueba.comentario)
//     //   populateValidParams(params)
        

 //         assert response.redirectedUrl == '/calificacion/show/404'
   //     assert controller.flash.message != null
   //     assert prueba.count() == 1
        
    }
}
