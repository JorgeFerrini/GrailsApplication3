package grailsapplication3



import grails.test.mixin.*
import org.junit.*
import grails.test.*

/**
 * See the API for {@link grails.test.mixin.services.ServiceUnitTestMixin} for usage instructions
 */
//@TestFor(CalificacionService)
class CalificacionServiceTests extends GrailsUnitTestCase {

    void testSomething() {
        def srv = new CalificacionService()
        Calificacion cali = new Calificacion()
        cali.setComentario("por favor introducelo")
        cali.setFechaCalificacion(srv.convertirFecha("12/03/2013"))
        cali.setValorCalificacion(5) 
        def testInstances =[cali]
        mockDomain(Calificacion, testInstances)
        def usu = new Usuario()
        usu.id= 393
        cali.usuario = usu
     
        def pro  = new Productos()
        pro.id= 116
        cali.producto = pro
       
        assertTrue   srv.guardarCalificacion(cali)
    }
    
        void testSomethingWrong() {
        def srv = new CalificacionService()
        Calificacion cali = new Calificacion()
        cali.setComentario("por favor introducelo")
        cali.setFechaCalificacion(srv.convertirFecha("12/03/2013"))
        cali.setValorCalificacion(5) 
        def testInstances =[cali]
        mockDomain(Calificacion, testInstances)
//        def usu = new Usuario()
//        usu.id= 393
//        cali.usuario = usu
//     
//        def pro  = new Productos()
//        pro.id= 116
//        cali.producto = pro
       
        assertTrue   srv.guardarCalificacion(cali)
    }
}
